package com.example.srini.vaibhavapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

public class LoginActivity extends AppCompatActivity {
    private Button mLogin;
    private Button mRegister;
    private EditText mUsername;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        mRegister = (Button)findViewById(R.id.registerButton);
        mLogin = (Button)findViewById(R.id.loginButton);
        mUsername = (EditText)findViewById(R.id.userNameText);

        mRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(LoginActivity.this,RegisterActivity.class);
                startActivity(intent);
            }
        });

        mLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(!mUsername.getText().toString().equals("")){
                    Intent intent = new Intent(LoginActivity.this,HomeActivity.class);
                    intent.putExtra("username",mUsername.getText().toString());
                    startActivity(intent);
                }
                else{
                    Toast toast = Toast.makeText(getApplicationContext(),
                            "Please Enter a valid UserName",
                            Toast.LENGTH_SHORT);
                    toast.show();
                }
            }
        });
    }
}
