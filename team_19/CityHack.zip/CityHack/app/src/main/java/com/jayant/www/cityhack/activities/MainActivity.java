package com.jayant.www.cityhack.activities;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.jayant.www.cityhack.utilities.TaskCompleted;
import com.jayant.www.cityhack.workers.registerWorker;

import com.jayant.www.cityhack.R;

public class MainActivity extends AppCompatActivity implements TaskCompleted {

    private Button signUp;
    private EditText eID;
    private EditText pass;

    private String user;
    private String passD;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        eID = findViewById(R.id.EID);
        pass = findViewById(R.id.password);

        signUp = findViewById(R.id.register);
        signUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                user = eID.getText().toString();
                passD = pass.getText().toString();

                if (TextUtils.isEmpty(user)) {
                    Toast.makeText(getApplicationContext(), "Enter EID!", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (TextUtils.isEmpty(passD)) {
                    Toast.makeText(getApplicationContext(), "Enter password!", Toast.LENGTH_SHORT).show();
                    return;
                }
                else {
                    login(view, user, passD);
                }
            }
        });

    }

    private void login(View view, String id, String pass) {

        /*   String type = "login";

        registerWorker registerWorker = new registerWorker(this);
        registerWorker.execute(type, id, pass);      */

        //Below line is only for development. Please remove when deploying project!
        Intent m = new Intent(MainActivity.this, HomeActivity.class);
        startActivity(m);

    }

    //this override the implemented method from AsyncResponse
    @Override
    public void onTaskComplete(String result) {
        //Here you will receive the result fired from async class
        //of onPostExecute(result) method.
        if (result.equals("successful")) {

            Toast.makeText(getApplicationContext(), "Successfully logged in!", Toast.LENGTH_LONG).show();

            SharedPreferences.Editor editor = getSharedPreferences("logged", MODE_PRIVATE).edit();
            editor.putString("id", user);
            editor.apply();

            Intent m = new Intent(MainActivity.this, HomeActivity.class);
            startActivity(m);
        }
        else {
            Log.d("pass", result);
            Toast.makeText(getApplicationContext(), "Invalid username or password!", Toast.LENGTH_LONG).show();
        }
    }


    @Override
    public void onBackPressed() {
        //do nothing
    }

}
