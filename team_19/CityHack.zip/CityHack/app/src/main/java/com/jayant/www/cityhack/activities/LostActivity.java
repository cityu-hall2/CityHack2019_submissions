package com.jayant.www.cityhack.activities;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.jayant.www.cityhack.R;

public class LostActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lost);
    }
}
