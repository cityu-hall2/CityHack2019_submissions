package com.jayant.www.cityhack.activities;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

import com.google.android.gms.vision.text.TextBlock;
import com.jayant.www.cityhack.R;

public class StudentActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student);

        String id = getIntent().getExtras().getString("id");
        TextView ID = findViewById(R.id.ID);
        ID.setText(id);

    }
}
