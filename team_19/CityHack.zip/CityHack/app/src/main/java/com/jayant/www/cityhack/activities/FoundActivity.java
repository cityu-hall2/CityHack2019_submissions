package com.jayant.www.cityhack.activities;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.jayant.www.cityhack.R;

public class FoundActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_found);

        Intent intent = getIntent();
        final String id = intent.getStringExtra("number");

        final EditText number = findViewById(R.id.cardNumber);
        number.setText(id);

        Button search = findViewById(R.id.search);
        search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(FoundActivity.this, StudentActivity.class);
                intent.putExtra("id", id);
                startActivity(intent);
            }
        });

    }
}
