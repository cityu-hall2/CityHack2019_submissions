package com.jayant.www.cityhack.utilities;

/**
 * Created by cypher on 26/1/2019.
 */

public interface TaskCompleted {
    // Define data you like to return from AysncTask
    public void onTaskComplete(String result);
}
