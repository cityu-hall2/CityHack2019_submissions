package com.jayant.www.screencast.Client;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Environment;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;

import com.jayant.www.screencast.Interface.TaskCompleted;
import com.jayant.www.screencast.MainActivity;
import com.jayant.www.screencast.Util.FileEvent;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.Socket;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.Arrays;

import static com.jayant.www.screencast.MainActivity.image;

/**
 * Created by cypher on 23/06/18.
 */

public class Client extends AsyncTask<String, Void, String> {

    String dstAddress;
    int dstPort;
    String response = "";


    Context context;
    private TaskCompleted mCallback;


    public Client(Context ctx) {
        context = ctx;
        this.mCallback = (TaskCompleted) context;
    }

    @Override
    protected String doInBackground(String... params) {

        dstAddress = params[0];
        dstPort = Integer.parseInt(params[1]);
        response = "";

        File file = new File(Environment.getExternalStorageDirectory(),"test.png");

        try {

            DatagramSocket clientSocket = new DatagramSocket(dstPort);
            byte[] receiveData = new byte[65507];

            while(true)
            {
                try {
                    DatagramPacket recPacket = new DatagramPacket(receiveData, receiveData.length);
                    Log.d("UDP", "S: Receiving...");

                    clientSocket.receive(recPacket);
                    byte[] buff = recPacket.getData();

                    final Bitmap newImg = BitmapFactory.decodeByteArray(buff, 0, buff.length);

                    MainActivity.mn.runOnUiThread(new Runnable() {

                        @Override
                        public void run() {

                            image.setImageBitmap(newImg);

                        }
                    });



                    InetAddress ipaddress = recPacket.getAddress();
                    int port = recPacket.getPort();
                    Log.d("IPAddress : ",ipaddress.toString());
                    Log.d(" Port : ",Integer.toString(port));
                }
                catch (IOException e) {
                    e.printStackTrace();
                    break;
                }
            }
        } catch (Exception e) {
            Log.e("UDP", "S: Error", e);


        }


        return null;
    }

    @Override
    protected void onPostExecute(String v) {
        mCallback.onTaskComplete(response);
        super.onPostExecute(v);
    }


    public class FlushedInputStream extends FilterInputStream {

        /**
         * The constructor that takes in the InputStream reference.
         *
         * @param inputStream the input stream reference.
         */
        public FlushedInputStream(final InputStream inputStream) {
            super(inputStream);
        }

        /**
         * Overriding the skip method to actually skip n bytes.
         * This implementation makes sure that we actually skip
         * the n bytes no matter what.
         * {@inheritDoc}
         */
        @Override
        public long skip(final long n) throws IOException {
            long totalBytesSkipped = 0L;
            //If totalBytesSkipped is equal to the required number
            //of bytes to be skipped i.e. "n"
            //then come out of the loop.
            while (totalBytesSkipped < n) {
                //Skipping the left out bytes.
                long bytesSkipped = in.skip(n - totalBytesSkipped);
                //If number of bytes skipped is zero then
                //we need to check if we have reached the EOF
                if (bytesSkipped == 0L) {
                    //Reading the next byte to find out whether we have reached EOF.
                    int bytesRead = read();
                    //If bytes read count is less than zero (-1) we have reached EOF.
                    //Cant skip any more bytes.
                    if (bytesRead < 0) {
                        break;  // we reached EOF
                    } else {
                        //Since we read one byte we have actually
                        //skipped that byte hence bytesSkipped = 1
                        bytesSkipped = 1; // we read one byte
                    }
                }
                //Adding the bytesSkipped to totalBytesSkipped
                totalBytesSkipped += bytesSkipped;
            }
            return totalBytesSkipped;
        }
    }





}
